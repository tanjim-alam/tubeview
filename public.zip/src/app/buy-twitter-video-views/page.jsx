import React from 'react';
import TwitterVideoViewsPage from './TwitterVideoViewsPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Twitter Video Views -  Tubeviews",
        description: "Buy Real Twitter Video Views -  Tubeviews"
    }
}

function page() {
    return <TwitterVideoViewsPage />
}

export default page