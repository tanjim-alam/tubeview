import React from 'react';
import InstagramLikesPage from './InstagramLikesPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Instagram Likes -  Tubeviews",
        description: "Buy Real Instagram Likes -  Tubeviews",
        keywords: 'Buy Instagram Likes, Buy Real Instagram Likes, Buy Instagram Likes Female',
    }
}

function page() {
    return <InstagramLikesPage />
}

export default page