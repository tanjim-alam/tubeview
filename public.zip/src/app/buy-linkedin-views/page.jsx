import React from 'react';
import LinkedInViewsPage from './LinkedInViewsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real LinkedIn Views -  Tubeviews",
        description: "Buy Real LinkedIn Views -  Tubeviews",
        keywords: "Buy Real LinkedIn Views, Buy LinkedIn Views"
    }
}

function page() {
    return <LinkedInViewsPage />
}

export default page