import React from 'react';
import InstagramTargetFollowersPage from './InstagramTargetFollowersPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Instagram Target Followers -  Tubeviews",
        description: "Buy Real Instagram Target Followers -  Tubeviews"
    }
}

function page() {
    return <InstagramTargetFollowersPage />
}

export default page