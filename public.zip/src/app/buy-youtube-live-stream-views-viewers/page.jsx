import React from 'react';
import YouTubeLiveViewsPage from './YouTubeLiveViewsPage';

export const generateMetadata = () => {
    return {
        title: "Buy YouTube Live Stream Views -  Tubeviews",
        description: "Buy YouTube Live Stream Views -  Tubeviews"
    }
}

function page() {
    return <YouTubeLiveViewsPage />
}

export default page