import React from 'react';
import SpotifyFollowersPage from './SpotifyFollowersPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Spotify Followers -  Tubeviews",
        description: "Buy Real Spotify Followers -  Tubeviews",
        keywords: "Buy Real Spotify Followers, Buy Spotify Followers"
    }
}

function page() {
    return <SpotifyFollowersPage />
}

export default page