import React from 'react';
import InstagramFollowersPage from './InstagramFollowersPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Instagram Followers -  Tubeviews",
        description: "Buy Real Instagram Followers -  Tubeviews"
    }
}

function page() {
    return <InstagramFollowersPage />
}

export default page