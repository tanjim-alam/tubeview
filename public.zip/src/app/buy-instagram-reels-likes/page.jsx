import React from 'react';
import InstagramReelsLikesPage from './InstagramReelsLikes';
export const generateMetadata = () => {
    return {
        title: "Buy Real Instagram Reels Likes -  Tubeviews",
        description: "Buy Real Instagram Reels Likes -  Tubeviews",
        keywords: 'Buy Instagram Reels Likes, Buy Real Instagram Reels Likes, Buy Instagram Reels Likes Female',
    }
}

function page() {
    return <InstagramReelsLikesPage />
}

export default page