import React from 'react';
import YouTubeCommentsPage from './YouTubeCommentsPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real YouTube Comments -  Tubeviews",
        description: "Buy Real YouTube Comments -  Tubeviews"
    }
}

function page() {
    return <YouTubeCommentsPage />
}

export default page