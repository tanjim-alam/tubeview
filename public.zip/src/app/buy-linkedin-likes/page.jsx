import React from 'react';
import LinkedInLikesPage from './LinkedInLikesPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real LinkedIn Likes -  Tubeviews",
        description: "Buy Real LinkedIn Likes -  Tubeviews",
        keywords: "Buy Real LinkedIn Likes, Buy LinkedIn Likes"
    }
}

function page() {
    return <LinkedInLikesPage />
}

export default page