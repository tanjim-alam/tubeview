import React from 'react';
import FacebookFollowersPage from './FacebookFollowersPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Facebook Followers -  Tubeviews",
        description: "Buy Real Facebook Followers -  Tubeviews"
    }
}

function page() {
    return <FacebookFollowersPage />
}

export default page