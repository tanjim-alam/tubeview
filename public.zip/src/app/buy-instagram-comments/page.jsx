import React from 'react';
import InstagramCommentsPage from './InstagramCommentsPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Instagram Comments -  Tubeviews",
        description: "Buy Real Instagram Comments -  Tubeviews"
    }
}

function page() {
    return <InstagramCommentsPage />
}

export default page