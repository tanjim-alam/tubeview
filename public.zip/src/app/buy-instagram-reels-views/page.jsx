import React from 'react';
import InstagramReelsViewsPage from './InstagramReelsViewsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Instagram Reels Views -  Tubeviews",
        description: "Buy Real Instagram Reels Views -  Tubeviews",
        keywords: 'Buy Instagram Reels Views, Buy Real Instagram Reels Views, Buy Instagram Reels Views Female',
    }
}

function page() {
    return <InstagramReelsViewsPage />
}

export default page