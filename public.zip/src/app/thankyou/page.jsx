import React from 'react'
import ThankYouPage from './ThankYouPage'

function page() {
    return (
        <ThankYouPage />
    )
}

export default page