import React from 'react';
import FacebookPageLikesPage from './FacebookPageLikesPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Facebook Page Likes -  Tubeviews",
        description: "Buy Real Facebook Page Likes -  Tubeviews"
    }
}

function page() {
    return <FacebookPageLikesPage />
}

export default page