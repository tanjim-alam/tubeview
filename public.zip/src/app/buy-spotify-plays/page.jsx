import React from 'react';
import SpotifyPlaysPage from './SpotifyPlaysPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Spotify Plays -  Tubeviews",
        description: "Buy Real Spotify Plays -  Tubeviews",
        keywords: "Buy Real Spotify Plays, Buy Spotify Plays"
    }
}

function page() {
    return <SpotifyPlaysPage />
}

export default page