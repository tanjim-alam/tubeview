import React from 'react';
import TikTokFollowersPage from './TiktokFollowerPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real TikTok Followers -  Tubeviews",
        description: "Buy Real TikTok Followers -  Tubeviews",
        keywords: "Buy Real TikTok Followers, Buy TikTok Followers"
    }
}

function page() {
    return <TikTokFollowersPage />
}

export default page