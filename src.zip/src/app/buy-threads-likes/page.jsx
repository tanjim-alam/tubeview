import React from 'react';
import ThreadsLikesPage from './ThreadsLikesPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Threads Likes -  Tubeviews",
        description: "Buy Real Threads Likes -  Tubeviews",
        keywords: "Buy Real Threads Likes, Buy Threads Likes"
    }
}

function page() {
    return <ThreadsLikesPage />
}

export default page