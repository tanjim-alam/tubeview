import React from 'react';
import FacebookLiveStreamViewsPage from './FacebookLiveStreamViewsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Facebook Live Stream Views -  Tubeviews",
        description: "Buy Real Facebook Live Stream Views -  Tubeviews",
        keyboards: "Buy Real Facebook Live Stream , Buy Facebook Live Viewers"
    }
}

function page() {
    return <FacebookLiveStreamViewsPage />
}

export default page