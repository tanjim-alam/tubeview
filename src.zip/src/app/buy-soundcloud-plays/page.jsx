import React from 'react';
import SoundCloudPlaysPage from './SoundCloudPlaysPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real SoundCloud Plays -  Tubeviews",
        description: "Buy Real SoundCloud Plays -  Tubeviews",
        keywords: "Buy Real SoundCloud Plays, Buy SoundCloud Plays"
    }
}

function page() {
    return <SoundCloudPlaysPage />
}

export default page