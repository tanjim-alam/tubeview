import React from 'react';
import PinterestRepinsPage from './PinterestRepinsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Pinterest Repins -  Tubeviews",
        description: "Buy Real Pinterest Repins -  Tubeviews",
        keywords: "Buy Real Pinterest Repins, Buy Pinterest Repins"
    }
}

function page() {
    return <PinterestRepinsPage />
}

export default page