import React from 'react';
import TwitchLiveViewersPage from './TwitchLiveViewersPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Twitch Live Viewers -  Tubeviews",
        description: "Buy Real Twitch Live Viewers -  Tubeviews",
        keywords: "Buy Real Twitch Live Viewers, Buy Twitch Live Viewers"
    }
}

function page() {
    return <TwitchLiveViewersPage />
}

export default page