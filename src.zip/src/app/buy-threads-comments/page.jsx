import React from 'react';
import ThreadsCommentsPage from './ThreadsCommentsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Threads Comments -  Tubeviews",
        description: "Buy Real Threads Comments -  Tubeviews",
        keywords: "Buy Real Threads Comments, Buy Threads Likes"
    }
}

function page() {
    return <ThreadsCommentsPage />
}

export default page