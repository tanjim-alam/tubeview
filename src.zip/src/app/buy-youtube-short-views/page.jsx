import React from 'react';
import YouTubeShortViewsPage from './YoutubeShortViews';

export const generateMetadata = () => {
    return {
        title: "Buy Real YouTube Short Views -  Tubeviews",
        description: "Buy Real YouTube Short Views -  Tubeviews",
        keywords: 'Buy Instagram Likes, Buy Real Instagram Likes, Buy Instagram Likes Female',
    }
}

function page() {
    return <YouTubeShortViewsPage />
}

export default page