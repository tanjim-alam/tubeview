import React from 'react';
import PinterestLikesPage from './PinterestLikesPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Pinterest Likes -  Tubeviews",
        description: "Buy Real Pinterest Likes -  Tubeviews",
        keywords: "Buy Real Pinterest Likes, Buy Pinterest Likes"
    }
}

function page() {
    return <PinterestLikesPage />
}

export default page