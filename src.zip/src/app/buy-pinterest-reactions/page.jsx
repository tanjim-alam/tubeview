import React from 'react';
import PinterestReactionsPage from './PinterestReactionsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Pinterest Reaction -  Tubeviews",
        description: "Buy Real Pinterest Reaction -  Tubeviews",
        keywords: "Buy Real Pinterest Reaction, Buy Pinterest Reaction"
    }
}

function page() {
    return <PinterestReactionsPage />
}

export default page