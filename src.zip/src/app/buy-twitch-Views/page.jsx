import React from 'react';
import TwitchViewsPage from './TwitchViewsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Twitch Views -  Tubeviews",
        description: "Buy Real Twitch Views -  Tubeviews",
        keywords: "Buy Real Twitch Views, Buy Twitch Views"
    }
}

function page() {
    return <TwitchViewsPage />
}

export default page