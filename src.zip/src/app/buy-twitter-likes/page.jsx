import React from 'react';
import TwitterLikesPage from './TwitterLikesPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Twitter Likes -  Tubeviews",
        description: "Buy Real Twitter Likes -  Tubeviews"
    }
}

function page() {
    return <TwitterLikesPage />
}

export default page