import React from 'react';
import FacebookLikesPage from './FacebookLikesPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Facebook Likes -  Tubeviews",
        description: "Buy Real Facebook Likes -  Tubeviews"
    }
}

function page() {
    return <FacebookLikesPage />
}

export default page