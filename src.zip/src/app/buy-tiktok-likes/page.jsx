import React from 'react';
import TikTokLikesPage from './TikTokLikesPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real TikTok Likes -  Tubeviews",
        description: "Buy Real TikTok Likes -  Tubeviews",
        keywords: "Buy Real TikTok Likes, Buy TikTok Likes"
    }
}

function page() {
    return <TikTokLikesPage />
}

export default page