import React from 'react';
import TwitchFollowersPage from './TwitchFollowersPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Twitch Followers -  Tubeviews",
        description: "Buy Real Twitch Followers -  Tubeviews",
        keywords: "Buy Real Twitch Followers, Buy Twitch Followers"
    }
}

function page() {
    return <TwitchFollowersPage />
}

export default page