import React from 'react';
import InstagramTargetLikesPage from './InstagramTargetLikesPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Instagram Target Likes -  Tubeviews",
        description: "Buy Real Instagram Target Likes -  Tubeviews"
    }
}

function page() {
    return <InstagramTargetLikesPage />
}

export default page