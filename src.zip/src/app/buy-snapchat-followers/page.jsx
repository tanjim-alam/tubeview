import React from 'react';
import SnapchatFollowersPage from './SnapchatFollowersPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Snapchat Followers -  Tubeviews",
        description: "Buy Real Snapchat Followers -  Tubeviews",
        keywords: "Buy Real Snapchat Followers, Buy Snapchat Followers"
    }
}

function page() {
    return <SnapchatFollowersPage />
}

export default page