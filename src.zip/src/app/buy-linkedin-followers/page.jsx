import React from 'react';
import LinkedInFollowersPage from './LinkedInFollowersPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real LinkedIn Followers -  Tubeviews",
        description: "Buy Real LinkedIn Followers -  Tubeviews",
        keywords: "Buy Real LinkedIn Followers, Buy LinkedIn Followers"
    }
}

function page() {
    return <LinkedInFollowersPage />
}

export default page