import React from 'react';
import LinkedInConnectionsPage from './LinkedInConnectionsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real LinkedIn Connections -  Tubeviews",
        description: "Buy Real LinkedIn Connections -  Tubeviews",
        keywords: "Buy Real LinkedIn Connections, Buy LinkedIn Connections"
    }
}

function page() {
    return <LinkedInConnectionsPage />
}

export default page