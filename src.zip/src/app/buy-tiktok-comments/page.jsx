import React from 'react';
import TikTokCommentsPage from './TiktokCommentsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real TikTok Comments -  Tubeviews",
        description: "Buy Real TikTok Comments -  Tubeviews",
        keywords: "Buy Real TikTok Comments, Buy TikTok Comments"
    }
}

function page() {
    return <TikTokCommentsPage />
}

export default page