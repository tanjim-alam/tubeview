import React from 'react';
import YouTubeLikesPage from './YouTubeLikesPage';

export const generateMetadata = () => {
    return {
        title: "Buy YouTube Likes -  Tubeviews",
        description: "Buy YouTube Likes -  Tubeviews"
    }
}

function page() {
    return <YouTubeLikesPage />
}

export default page