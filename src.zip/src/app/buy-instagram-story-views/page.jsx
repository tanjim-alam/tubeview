import React from 'react';
import InstagramStoryViewsPage from './InstagramStoryViewsPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Instagram Story Views -  Tubeviews",
        description: "Buy Real Instagram Story Views -  Tubeviews"
    }
}

function page() {
    return <InstagramStoryViewsPage />
}

export default page