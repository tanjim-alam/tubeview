import React from 'react';
import SoundCloudFollowersPage from './SoundCloudFollowersPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real SoundCloud Followers -  Tubeviews",
        description: "Buy Real SoundCloud Followers -  Tubeviews",
        keywords: "Buy Real SoundCloud Followers, Buy SoundCloud Followers"
    }
}

function page() {
    return <SoundCloudFollowersPage />
}

export default page