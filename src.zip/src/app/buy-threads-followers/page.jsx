import React from 'react';
import ThreadsFollowersPage from './ThreadsFollowersPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Threads Followers -  Tubeviews",
        description: "Buy Real Threads Followers -  Tubeviews",
        keywords: "Buy Real Threads Followers, Buy Threads Followers"
    }
}

function page() {
    return <ThreadsFollowersPage />
}

export default page