import React from 'react'
import YouTubeViewsPage from './YouTubeViewsPage';

export const generateMetadata = () => {
    return {
        title: "Buy YouTube Views -  Tubeviews",
        description: "Buy YouTube Views -  Tubeviews"
    }
}

export default function Page() {
    return <YouTubeViewsPage />;
}
