import React from 'react';
import PinterestFollowersPage from './PinterestFollowersPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Pinterest Followers -  Tubeviews",
        description: "Buy Real Pinterest Followers -  Tubeviews",
        keywords: "Buy Real Pinterest Followers, Buy Pinterest Followers"
    }
}

function page() {
    return <PinterestFollowersPage />
}

export default page