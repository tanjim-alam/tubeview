import React from 'react';
import YouTubeViews50000Page from './YouTubeViews50000Page';
export const generateMetadata = () => {
    return {
        title: "Buy Real 50000 YouTube Views -  Tubeviews",
        description: "Buy Real 50000 YouTube Views -  Tubeviews",
        keywords: "Buy Real 50000 YouTube Views, Buy 50000 YouTube Views"
    }
}

function page() {
    return <YouTubeViews50000Page />
}

export default page