import React from 'react';
import FacebookVideoViewsPage from './FacebookVideoViewsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Facebook Video Views -  Tubeviews",
        description: "Buy Real Facebook Video Views -  Tubeviews"
    }
}

function page() {
    return <FacebookVideoViewsPage />
}

export default page