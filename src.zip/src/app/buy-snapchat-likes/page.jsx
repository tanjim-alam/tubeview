import React from 'react';
import SnapchatLikesPage from './SnapchatLikesPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Snapchat Likes -  Tubeviews",
        description: "Buy Real Snapchat Likes -  Tubeviews",
        keywords: "Buy Real Snapchat Likes, Buy Snapchat Likes"
    }
}

function page() {
    return <SnapchatLikesPage />
}

export default page