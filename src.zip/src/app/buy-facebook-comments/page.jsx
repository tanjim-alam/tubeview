import React from 'react';
import FacebookCommentsPage from './FacebookCommentsPage';
export const generateMetadata = () => {
    return {
        title: "Buy Real Facebook Comments -  Tubeviews",
        description: "Buy Real Facebook Comments -  Tubeviews"
    }
}

function page() {
    return <FacebookCommentsPage />
}

export default page