import React from 'react';
import TwitterFollowersPage from './TwitterFollowersPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Twitter Followers -  Tubeviews",
        description: "Buy Real Twitter Followers -  Tubeviews"
    }
}

function page() {
    return <TwitterFollowersPage />
}

export default page