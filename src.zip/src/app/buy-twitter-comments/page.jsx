import React from 'react';
import TwitterCommentsPage from './TwitterCommentsPage';

export const generateMetadata = () => {
    return {
        title: "Buy Real Twitter Comments -  Tubeviews",
        description: "Buy Real Twitter Comments -  Tubeviews"
    }
}

function page() {
    return <TwitterCommentsPage />
}

export default page